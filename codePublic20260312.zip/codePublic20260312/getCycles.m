function [seg] = getCycles(x, oafHz)

pars.estRF.Tresp_range_breathsMin = [6 20];
%pars step 2
pars.lowCutOff_Hz = 0.05;
%pars step 3 (run if ~= 0)
pars.baselineSpan_nPeaks = 5;
%step 4
pars.volThresholdIn_pMedian = 0.2;
pars.volThresholdEx_pMedian = 0.2;
pars.timeThresholdIn_pMedian = 0.2;
pars.timeThresholdEx_pMedian = 0.2;
[seg,~,~] = cyclesAdvance(oafHz, cumsum(x)', pars) ;


% align detected expiration beginning time
QQ = median(x(seg.begEx)) ;

for jj = 1: length(seg.begEx)
    idx = max(1, seg.begEx(jj) - oafHz): min(length(x), seg.begEx(jj) + oafHz) ;
    [~, aa] = min(abs(x(idx) - QQ)) ;
    seg.begEx(jj) = seg.begEx(jj) - oafHz - 1 + aa ;
end


% correct boundary points
if seg.begIn(1) > seg.begEx(1) ; seg.begIn(1) = [] ; end
if length(seg.begIn) > length(seg.begEx) ; seg.begIn(end) = [] ; end




% correct the beginning time of expiration
diffof = smooth(diff(x), oafHz/2, 'loess')*oafHz/5 ;
tmpidx = find(diffof(seg.begEx(1:end-1)) > 0) ;
for ll = 1: length(tmpidx)
    tmp = seg.begIn(tmpidx(ll))+1 : seg.begIn(tmpidx(ll)+1) ;
    [~, b] = min(diffof(tmp)) ;
    seg.begEx(tmpidx(ll)) = seg.begIn(tmpidx(ll)) + b ;

    % do a correction to get 0
    tmp = seg.begEx(tmpidx(ll)) - 30 + 1: seg.begEx(tmpidx(ll)) + 30 ;
    [~, b] = min(abs(x(tmp))) ; clear tmp
    seg.begEx(tmpidx(ll)) = seg.begEx(tmpidx(ll)) - 30 + b ;

    tmp = seg.begEx(tmpidx(ll)) - 30 + 1: seg.begEx(tmpidx(ll)) + 30 ;
    [~, b] = min(abs(x(tmp))) ; clear tmp
    seg.begEx(tmpidx(ll)) = seg.begEx(tmpidx(ll)) - 30 + b ;

    tmp = seg.begEx(tmpidx(ll)) - 30 + 1: seg.begEx(tmpidx(ll)) + 30 ;
    [~, b] = min(abs(x(tmp))) ; clear tmp
    seg.begEx(tmpidx(ll)) = seg.begEx(tmpidx(ll)) - 30 + b ;
end


seg.begEx = sort(seg.begEx) ;





