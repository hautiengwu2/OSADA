function [xc, xq, Y, YOSc, YOSc2] = OSdecomp(x, locsf, p1, p2, EXT)

% EXT is used to determine the local trend. 
% it is under the ASSUMPTION that the pattern is compactly supported
% or at least can be well approximated by compactly supported

p = p1+p2+1 ;
n = length(locsf) ;
Y = zeros(p, n) ;


p1e = p1 + EXT ; p2e = p2 + EXT ;
pe = p1e + p2e + 1 ;
X = [ones(pe,1) [-p1e:p2e]'] ;
Xb = X([1:EXT pe-EXT+1:pe], :) ;

for jj = 1: length(locsf)
    if locsf(jj)-p1e < 1
        tmp = x(1: locsf(jj)+p2e) ;
        tmp = [zeros(pe-length(tmp),1); tmp] ;
    else
        tmp = x(locsf(jj)-p1e: min(locsf(jj)+p2e, length(x))) ;
        if length(tmp) < pe
            tmp = [tmp; zeros(pe-length(tmp), 1)] ;
        end
    end
    
    b = (Xb'*Xb) \ (Xb'*(tmp([1:EXT pe-EXT+1:pe])-median(tmp))) ;
    tmp = tmp - median(tmp) - X*b ;
    Y(:, jj) = tmp(EXT+1 : EXT+p) ;
end

% run OS
[YOSc, eta, r_p, k] = optimal_shrinkage_color(Y, 'fro', 1/2.01) ;
disp([r_p k])

[ind2, ~] = knnsearch(YOSc', YOSc', 'k', 30) ;
YOSc2 = zeros(size(Y)) ;
for ii = 1: size(Y, 2)
    YOSc2(:, ii) = median(Y(:, ind2(ii,:)), 2) ;
end

xq = zeros(size(x)) ;
xc = x ;
for jj = 1: length(locsf)
    if locsf(jj)-p1 < 1
        idx = 1: locsf(jj)+p2 ;
        tmp = YOSc2(p-length(idx)+1: p, jj) ;
    else
        idx = locsf(jj)-p1: min(locsf(jj)+p2, length(x)) ;
        tmp = YOSc2(1:length(idx), jj) ;
    end
    xc(idx) = xc(idx) - tmp ;
    xq(idx) = xq(idx) + tmp ;
end

