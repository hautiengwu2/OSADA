for Hidx = 1: 4
    COstrOSA = [] ;
    COstrCSA = [] ;
    COstrHYP = [] ;
    COstrNOR = [] ;
    % 1=csa，2=osa，3=hypopnea
    
    for Jidx = 1: N
        QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 0, 5) ;
        COstrNOR = [COstrNOR; OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 0, Hidx)./QQ] ;
        QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 3, 5) ;
        COstrHYP = [COstrHYP; OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 3, Hidx)./QQ] ;
        QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 2, 5) ;
        COstrOSA = [COstrOSA; OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 2, Hidx)./QQ] ;
        QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 1, 5) ;
        COstrCSA = [COstrCSA; OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 1, Hidx)./QQ] ;
    end

    COstr{1} = COstrNOR(~isnan(COstrNOR)) ;
    COstr{2} = COstrHYP(~isnan(COstrHYP)) ;
    COstr{3} = COstrOSA(~isnan(COstrOSA)) ;
    COstr{4} = COstrCSA(~isnan(COstrCSA)) ;

    figure ;
    [h,L,MX,MED] = violin(COstr) ;
    ylim([0 quantile(COstrNOR, .99)])
    LABEL = {'Normal', 'Hypopnea', 'OSA', 'CSA'} ;
    set(gca,'TickLabelInterpreter', 'latex');
    set(gca,'xtick',1:length(LABEL))
    set(gca,'xticklabel', LABEL) ;
    set(gca,'fontsize', 28) ;
    ylabel([num2str(Hidx) '-th CO-str'], 'interpreter', 'latex')
end


% this is all harmonics
COstrOSA = [] ;
COstrCSA = [] ;
COstrHYP = [] ;
COstrNOR = [] ;
% 1=csa，2=osa，3=hypopnea

for Jidx = 1: N
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 0, 5) ;
    COstrNOR = [COstrNOR; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 0, 1:4), 2)./QQ] ;
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 3, 5) ;
    COstrHYP = [COstrHYP; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 3, 1:4), 2)./QQ] ;
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 2, 5) ;
    COstrOSA = [COstrOSA; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 2, 1:4), 2)./QQ] ;
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 1, 5) ;
    COstrCSA = [COstrCSA; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 1, 1:4), 2)./QQ] ;
end

COstr{1} = COstrNOR(~isnan(COstrNOR)) ;
COstr{2} = COstrHYP(~isnan(COstrHYP)) ;
COstr{3} = COstrOSA(~isnan(COstrOSA)) ;
COstr{4} = COstrCSA(~isnan(COstrCSA)) ;

figure ;
[h,L,MX,MED] = violin(COstr) ;
ylim([0 quantile(COstrNOR, .99)])
LABEL = {'Normal', 'Hypopnea', 'OSA', 'CSA'} ;
set(gca,'TickLabelInterpreter', 'latex');
set(gca,'xtick',1:length(LABEL))
set(gca,'xticklabel', LABEL) ;
set(gca,'fontsize', 28) ;
ylabel(['all harm. CO-str'], 'interpreter', 'latex')



% AHI vs CO global
XX = zeros(N, 6);
for jj=1:N ; XX(jj, :) = OCstrGLOBAL{jj} ; end
plot(XX(:, 6), sum(XX(:, 1:4),2) ./ XX(:, 5), 'kd', 'linewidth',3)
xlabel('AHI') ; ylabel('OC-str') ; set(gca,'fontsize', 20) ;
mdl = fitlm(XX(:, 6), sum(XX(:, 1:4),2) ./ XX(:, 5)) ;






% different severity
IDX1 = find(XX(:, 6) < 15) ;
IDX2 = find(XX(:, 6) >= 15) ;

COstrOSA = [] ;
COstrCSA = [] ;
COstrHYP = [] ;
COstrNOR = [] ;
% 1=csa，2=osa，3=hypopnea

for jj = 1:length(IDX1)
    Jidx = IDX1(jj) ;
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 0, 5) ;
    COstrNOR = [COstrNOR; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 0, 1:4), 2)./QQ] ;
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 3, 5) ;
    COstrHYP = [COstrHYP; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 3, 1:4), 2)./QQ] ;
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 2, 5) ;
    COstrOSA = [COstrOSA; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 2, 1:4), 2)./QQ] ;
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 1, 5) ;
    COstrCSA = [COstrCSA; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 1, 1:4), 2)./QQ] ;
end

COstr{1} = COstrNOR(~isnan(COstrNOR)) ;
COstr{2} = COstrHYP(~isnan(COstrHYP)) ;
COstr{3} = COstrOSA(~isnan(COstrOSA)) ;
COstr{4} = COstrCSA(~isnan(COstrCSA)) ;


COstrOSA = [] ;
COstrCSA = [] ;
COstrHYP = [] ;
COstrNOR = [] ;

for jj = 1:length(IDX2)
    Jidx = IDX2(jj) ;
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 0, 5) ;
    COstrNOR = [COstrNOR; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 0, 1:4), 2)./QQ] ;
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 3, 5) ;
    COstrHYP = [COstrHYP; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 3, 1:4), 2)./QQ] ;
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 2, 5) ;
    COstrOSA = [COstrOSA; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 2, 1:4), 2)./QQ] ;
    QQ = OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 1, 5) ;
    COstrCSA = [COstrCSA; sum(OCstrLOCAL{Jidx}(OCstrLOCAL{Jidx}(:, 6) == 1, 1:4), 2)./QQ] ;
end

COstr{5} = COstrNOR(~isnan(COstrNOR)) ;
COstr{6} = COstrHYP(~isnan(COstrHYP)) ;
COstr{7} = COstrOSA(~isnan(COstrOSA)) ;
COstr{8} = COstrCSA(~isnan(COstrCSA)) ;

figure ;
[h,L,MX,MED] = violin(COstr) ;
ylim([0 quantile(COstrNOR, .99)])
LABEL = {'Normal ($<15$)', 'Hypopnea ($<15$)', 'OSA ($<15$)', 'CSA ($<15$)',...
    'Normal ($>=15$)', 'Hypopnea ($>=15$)', 'OSA ($>=15$)', 'CSA ($>=15$)'} ;
set(gca,'TickLabelInterpreter', 'latex');
set(gca,'xtick',1:length(LABEL))
set(gca,'xticklabel', LABEL) ;
set(gca,'fontsize', 28) ;
ylabel(['all harm. CO-str'], 'interpreter', 'latex')
