function [CObpf100, DDairflowbpf100, COsgf100, DDairflowsgf100] = OtherAlgorithm(x, iHR, Hz)

% assume the input is 400Hz
% unit of iHR = beats/min

oafHz = 100 ;
DS = Hz/oafHz ;

% BPF
[b, a] = butter(4, [quantile(iHR, .01)/60-0.1 quantile(iHR, .99)/60+0.1]/(oafHz/2)) ;
CObpf100 = filtfilt(b, a, x(1:DS:end)) ;

DDairflowbpf100 = x(1:DS:end) - CObpf100 ;
[b, a] = butter(4, [0.1 10]/(oafHz/2)) ;
DDairflowbpf100 = filtfilt(b, a, DDairflowbpf100) ;

% SGF
DDairflowsgf100 = sgolayfilt(x(1:DS:end), 2, 2*oafHz+1) ;
[b, a] = butter(4, [quantile(iHR, .01)/60-0.1 quantile(iHR, .99)/60+0.1]/(oafHz/2)) ;
COsgf100 = filtfilt(b, a, x(1:DS:end)-DDairflowsgf100) ;