function [xq2, OCx2, CHECK, Y, YOSc2, PERIODL] = DecomposeSig(x, x0, oafHz, begEx, LOS)

% assume begEx has been well controlled!


% (Step 1) collect cycles landmarks and determine p
begEx = sort(begEx, 'ascend') ;
Qdiff = diff(begEx) ;


% if cycle-to-cycle interval is short, remove!
begEx(Qdiff < oafHz*0.5) = [] ;


% to calculse p, if interval>10s, don't take it into account.
% But use this threshold to determine apnea for now.
% (8=10-2, where 2 is indicated by  M B Uddin et al 2021 Physiol. Meas. 42 015001)
THRESHOLD = 8 ;



% this one doesn't count on experts' label but use 8 s cut
p1 = ceil(quantile(Qdiff(Qdiff<oafHz*THRESHOLD), .95)) ;
p2 = p1 ;
p = p1 + p2 + 1 ;

clear Qdiff ;
fprintf(['initial number, n = ' num2str(length(begEx)) '\n'])




% (Step 2) classify breathing cycles
% remove the first and final cycles (simply to simplify the code)
n = length(begEx) ;
for eidx = length(begEx):-1:1
    if begEx(eidx) < p1
        begEx(eidx) = [] ;
        n = n - 1 ;
    end
    if begEx(eidx) + p2 > length(x)
        begEx(eidx) = [] ;
        n = n - 1 ;
    end
end

fprintf(['after removing first/final cycles, n = ' num2str(n) '\n'])

% if two "cycles" are too close related to p, remove one!
begEx(diff(begEx) < p/10) = [] ;


% assume cycles around apnea events are special, chaotic-- handle them separately
Qdiff = diff(begEx) ;

NearApneaCycles = find(Qdiff > oafHz * THRESHOLD) ;
NearApneaCycles = sort(unique([NearApneaCycles NearApneaCycles+1])) ;
clear Qdiff ;




% attach period information to each cycle
% -999 means apnea event-related cycles, -1000 means pseudo-cycles (simply for
% stitching purpose)
PERIODL = -999*ones(size(begEx)) ;

% Assumption: the first and the last cycles are not apnea!
PERIODL(1) = (begEx(2) - begEx(1) + 1) * 2 ;
PERIODL(end) = (begEx(end) - begEx(end-1) + 1) * 2 ;

% if not apnea-related cycles, set PERIODL
for eidx = setdiff(2: length(begEx)-1, NearApneaCycles)
    %if begEx(eidx) - begEx(eidx-1) < THRESHOLD*oafHz && begEx(eidx+1) - begEx(eidx) < THRESHOLD*oafHz
        PERIODL(eidx) = begEx(eidx+1) - begEx(eidx-1) + 1 ;
    %end
end


% fill in "pseudo-cycles" for apnea events.
Exidx = begEx ;
tmpidx = find(begEx(2:end) - begEx(1:end-1) >= p*9/10) ;

for eidx = 1: length(tmpidx)
    ntmp = ceil((begEx(tmpidx(eidx)+1) - begEx(tmpidx(eidx))) / (4*p/5)) ;
    Extmp = round(linspace(begEx(tmpidx(eidx)), begEx(tmpidx(eidx)+1), ntmp+1)) ;
    Extmp(end) = [] ; Extmp(1) = [] ;

    Exidx = [Exidx Extmp] ;
    PERIODL = [PERIODL -1000*ones(1, length(Extmp))] ;
    n = n + ntmp ;
end

[Exidx, tmp] = sort(Exidx) ;
PERIODL = PERIODL(tmp) ;




n = length(Exidx) ;
Y = zeros(p, n) ;
fprintf(['final (p, n) = (' num2str(p) ', ' num2str(n) ')\n'])



% (Step 3) collect cycles

for jj = 1: length(Exidx)

    % the 1st and last cycles should be good now!
    tmp = x(Exidx(jj)-p1: Exidx(jj)+p2) ;
    
    % smoothen the boundary (why only use 1s before?)
    %if jj > 1 && Exidx(jj)-p1 < Exidx(jj-1) + oafHz
    %     Qn = Exidx(jj-1) + oafHz - (Exidx(jj)-p1) ;
    if jj > 1 && Exidx(jj)-p1 < Exidx(jj-1) + round(p2/4)
        Qn = Exidx(jj-1) + round(p2/4) - (Exidx(jj)-p1) ;
        %tmp(1:Qn) = tmp(1:Qn) .* sin((pi/2)*[0: Qn-1]/Qn).^2 ;
        tmp(1:Qn) = tmp(1:Qn) .* sin((pi/2)*linspace(0,1,Qn)).^2 ;
    elseif jj == 1 % firt cycle
        Qn = round(p1/4) ;
        tmp(1:Qn) = tmp(1:Qn) .* sin((pi/2)*linspace(0,1,Qn)).^2 ;
    end

    %if jj < length(Exidx) && Exidx(jj)+p2 > Exidx(jj+1) - oafHz
    %    Qn = Exidx(jj)+p2 - (Exidx(jj+1) - oafHz) ;
    if jj < length(Exidx) && Exidx(jj)+round(p1/4) > Exidx(jj+1) - p2
        Qn = Exidx(jj)+p2 - (Exidx(jj+1) - round(p1/4)) ;
        %tmp(end-Qn+1:end) = tmp(end-Qn+1:end) .* cos((pi/2)*[0: Qn-1]/Qn).^2 ;
        tmp(end-Qn+1:end) = tmp(end-Qn+1:end) .* cos((pi/2)*linspace(0,1,Qn)).^2 ;
    elseif jj == length(Exidx) % last cycle
        Qn = round(p2/4) ;
        tmp(end-Qn+1:end) = tmp(end-Qn+1:end) .* cos((pi/2)*linspace(0,1,Qn)).^2 ;
    end

    Y(:, jj) = tmp ;

end




%[bb,aa] = butter(4, 6/(oafHz/2), 'low') ;
YY = zeros(p, n) ;
for ll = 1: n
    if max(Y(:,ll)) ~= 0
        YY(1:p, ll) = Y(:, ll) ./ max(Y(:,ll)) ;
    end
end


YOSc2 = zeros(p, n) ;



if LOS == 1000

    fprintf('!!!! RUN rank-1 SVD with Linfty. ONLY USED to generate simulation!!!!! \n')

    [Qidx, ~] = knnsearch(YY', YY', 'k', 30) ;

    for ll = 1: n
        if ~mod(ll, 10) ; waitbar(ll/n) ; end
        if PERIODL(ll) > 0 
            [u,l,v] = svd(Y(:, Qidx(ll,:))) ;
            YOSc2(:, ll) = u(:, 1)*l(1,1)*v(1,1) ;
        end
    end


else

    HANDLEDN = 0 ; % for debug purpose
    fprintf(['RUN the key step of OSADA. #groups = ' num2str(LOS) '\n'])

    fprintf(['handle main cycles\n']) ;
    idxtmp = find(PERIODL >= -999) ;
    HANDLEDN = HANDLEDN + length(idxtmp) ;

    if ~isempty(idxtmp)

        GPno = LOS ;
        [cidx, ~] = kmeans(YY(:, idxtmp)', GPno) ;

        
        %t1 = tic ; 
        %[cidx2, c] = kmedoids(YY(:, idxtmp)', GPno, 'Distance', @dtwf) ;
        %toc(t1)



        for jj = 1: GPno

            tmp = find(cidx == jj) ;
            Ytmp = Y(:, idxtmp(tmp)) ;

            if length(tmp) > 20
                [tmpc, eta, r_p, k, U, V, s] = optimal_shrinkage_color(Ytmp,...
                    'fro', min(1/2.01, 1/log(log(length(tmp))))) ;
                fprintf(['\tUse OS: (n, r_p, k) = ('...
                    num2str(length(tmp)) ', ' num2str(r_p) ', ' num2str(k) ')\n'])
            else
                tmpc = Ytmp ; 
                fprintf(['\tSmall group -- Use top SV only: n = ' num2str(length(tmp)) '\n'])
            end

            YOSc2(:, idxtmp(tmp)) = tmpc ;
        end

    end


    fprintf(['handle apnea-related cycles\n']) ;
    
    if 0
    idxtmp = find(PERIODL == -999) ;
    HANDLEDN = HANDLEDN + length(idxtmp) ;

    if ~isempty(idxtmp)
        if length(idxtmp) > 500
            GPno = LOS ;
            [cidx, ~] = kmeans(Y(:, idxtmp)', GPno) ;
        else
            GPno = 1 ;
            cidx = ones(length(idxtmp), 1) ;
        end


        for jj = 1: GPno

            tmp = find(cidx == jj) ;
            Ytmp = Y(:, idxtmp(tmp)) ;

            if length(tmp) > 50
                [tmpc, eta, r_p, k, U, V, s] = optimal_shrinkage_color(Ytmp,...
                    'fro', min(1/2.01, 1/log(log(length(tmp))))) ;
                fprintf(['\tMany apnea events -- Use OS: (n, r_p, k) = ('...
                    num2str(length(tmp)) ', ' num2str(r_p) ', ' num2str(k) ')\n'])
            else
                [u,l,v] = svd(Ytmp) ;
                tmpc = u(:,1)*l(1,1)*v(:,1)' ;
                fprintf(['\tSmall group -- Use top SV only: n = ' num2str(length(tmp)) '\n'])
            end

            YOSc2(:, idxtmp(tmp)) = tmpc ;
        end
    end
    end

    idxtmp = find(PERIODL == -1000) ;
    HANDLEDN = HANDLEDN + length(idxtmp) ;

    if HANDLEDN ~= n
        fprintf(['ERROR in the cycles numbers!! ' num2str(HANDLEDN) ', ' num2str(n) ' \n'])
    end

end



[xq2, CHECK] = stitchALL(YOSc2, Exidx, length(x), p1) ;
xq2 = xq2' ; CHECK = CHECK' ;


% clip in real data
xq2(xq2 > 100) = 100 ; xq2(xq2 < -100) = -100 ;

OCx2 = x0 - xq2 ;


OCx2(x0 == 100) = 0 ; OCx2(x0 == -100) = 0 ;
