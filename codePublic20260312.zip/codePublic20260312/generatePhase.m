function [PHI, time] = generatePhase(SIG, PPGHz)

% input SIG should be oscilaltory signals like airflow, PPG, etc


% resample to 100Hz. You can consider other sampling rate if needed
ppgx2 = resample(SIG, 100, PPGHz) ;


% apply any landmark detection algorithm. This one is for PPG
[~, Rs, ~, ~] = PPG_peakdetection2(ppgx2, 100) ;

% apply some physiological constraint. This one is for PPG
Rs = Rs(diff(Rs) > 20) ;


% generate the phase. Use PPG as an example.
% cardiac component phase at 100Hz
% take care of the boundary
tmpRs0 = Rs ; 
tmpphi0 = 1:length(Rs) ;
if Rs(1) > 1
    tmpRs0 = [1; tmpRs0] ;
    tmpphi0 = [1-(Rs(1)/(Rs(2)-Rs(1))) tmpphi0] ;
end

if Rs(end) < length(ppgx2)
    tmpRs0 = [tmpRs0; length(ppgx2)] ;
    tmpphi0 = [tmpphi0 length(Rs)+(length(ppgx2)-Rs(end))/(Rs(end)-Rs(end-1))] ;
end
tmpRs0 = tmpRs0 / 100 ;

% time is the absolute time for warpping
time = [1:length(ppgx2)] / 100 ;

% PHI is \phi(t), where \phi(0) might be different from 0
PHI = interp1(tmpRs0, tmpphi0, time, 'linear', 'extrap') ;