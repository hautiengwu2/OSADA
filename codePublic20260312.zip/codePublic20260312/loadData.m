

% load your database. Adjust it to your data format

ggg = dir(['../' DATABASE '/20*.mat']) ;



load(['../' DATABASE '/' ggg(Jidx).name])

fprintf([ggg(Jidx).name '\n'])

%% collect data or load saved data
oafHz = double(airflow.fs) ;
PPGHz = double(red.ppg.fs) ;

oaf = double(airflow.signal) ;
ABD = double(abdomen.signal) ;
THO = double(thorax.signal) ;
PPG = double(red.ppg.signal) ;
trend = medfilt1(PPG, 300) ;
PPG = PPG - trend ;
AL = double(apnea_event.signal) ;
ALHz = double(apnea_event.fs) ;
STAGE = double(sleep_stage.signal) ;
STAGEHz = double(sleep_stage.fs) ;

t = AL > 0 ;
[M, start] = regexp(sprintf('%i', [0 t]), '1+', 'match');
M = cellfun(@length, M);
AHI = length(M)/ (length(AL)/ALHz/60/60) ;

% get IHR
IHRP = double((red.ihr.signal + green.ihr.signal))/2 ;
IHRHz = double(red.ihr.fs) ;


% the main segment we analyze
SS = 0 ; ES = length(oaf)/oafHz ; % whole recording
x = oaf(SS*oafHz+1:ES*oafHz) ; % reduce to 10 Hz to speed up
ppgx = PPG(SS*PPGHz+1:ES*PPGHz) ;
IHRx = IHRP(SS*IHRHz+1: ES*IHRHz) ;
ALx = AL(SS*ALHz+1: ES*ALHz) ;
STAGEx = STAGE(SS*STAGEHz+1: ES*STAGEHz) ;


% apply algorithm to get systolic phase landmarks
[R1, Rs, Q, ~] = PPG_peakdetection2(ppgx, PPGHz) ;


