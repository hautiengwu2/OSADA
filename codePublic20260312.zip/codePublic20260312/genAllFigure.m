clear ; close all

%% this is modified from AnalyzeREAL20250325.m

PATH = '/Users/hautiengwu/Dropbox/___course/2025 sinica summer school/Matlab code' ;
addpath([PATH '/SST']) ;
addpath('./deshape') ;
addpath([PATH '/SAMD']) ;
addpath([PATH '/tool']) ;
addpath([PATH '/tool/export_fig']) ;
addpath('/Users/hautiengwu/Dropbox/___working tex since 20221228/_WORKING Rapoport CO OSADA/code') ;
addpath('/Users/hautiengwu/Dropbox/code/common') ;
addpath('/Users/hautiengwu/Dropbox/code/tidal_breathing_segmentation-master') ;
%addpath('./AllTFR') ;

scrsz = get(0,'ScreenSize') ;
DATABASE = 'database PranaQ' ;
FONTSIZE = 28 ; %40 ;
PLOTOCFFT = 1 ;
warningState = warning;  % Save current warning state
warning('off', 'all');   % Disable all warnings



Artifact9p5HzLIST = [1 3 5 6 9 10 11 13 14 15 16 17 19 20 21 22 23 24 26 27 ...
    29 31 33 35 36 37 39 40 41 42 43 44 45 46 50 52 53 54 55 56 57 58 ...
    59 61 62 65 66 67 69 71 72 73 74 75] ;

Artifact9HzLIST = [3 4 6 7 11 13 19 29 33 34 36 41 42 43 44 45 51 52 ...
    53 54 57 58 61 62 67 69 71 72 75] ;

Artifact4p5HzLIST = [3 6 11 13 15 19 20 24 29 33 34 36 42 43 44 45 51 53 ...
    54 61 67 71 72 75] ;


POLAR_Change = [12 15 39 40 75] ; % only cases with strong CO



% time is in min
OCtime{9} = [13 23] ; % [13 23] for Figure 5 6, CSA
%OCtime{9} = [123 132] ; 
%OCtime{9} = [205 214] ; 
OCtime{15} = [5e5 5.48e5]/100/60 ;
OCtime{53} = [298 306] ;
OCtime{63} = (1.803e6+[0 4.8e4])/100/60 ; % for Figure 7 8, OSA
OCtime{75} = [29.8 39] ; % for Figure 3 4, normal
%OCtime{75} = [12 21] ;


MULTI1{9} = 1 ;
DIV1{9} = 1 ;
MULTI2{9} = 1 ;
DIV2{9} = 1 ;
MMM{9} = 4 ;

MULTI1{63} = 1 ;
DIV1{63} = 1 ;
MULTI2{63} = 1 ;
DIV2{63} = 1 ;
MMM{63} = 6 ;

MULTI1{75} = 2 ;
DIV1{75} = 1 ;
MULTI2{75} = 2 ;
DIV2{75} = 2 ;
MMM{75} = 9 ;




%% run analysis for all subjects
for Jidx = 9 %63 %15

    fprintf(['\n\n**** ' num2str(Jidx) '\n'])
    loadData ;

    %% preprocess the signal
    % correct the gap
    if ~isempty(BROKEN)
        for kk= 1: size(BROKEN, 1)
            x(BROKEN(kk, 1)*oafHz+1: BROKEN(kk, 2)*oafHz) = 0 ;
        end
    end

    if ismember(Jidx, POLAR_Change)
        x = -x ; oaf = -oaf ;
    end




    % correct OOR

    x0 = x ;
    idxbad = find(x == 100 | x == -100) ;
    idxgood = find(x < 100 & x > -100) ;
    x = interp1(idxgood, x(idxgood), [1:length(x)], 'spline', 'extrap') ;

    OORratio = round(10000 * length(idxbad) ./ length(x)) / 100 ;
    fprintf([num2str(Jidx) ': OOR ratio = ' num2str(OORratio) '%%\n']) ;


    AL = double(VGH.apnea_event.signal) ;
    t = AL > 0 ;
    [M, start] = regexp(sprintf('%i', [0 t]), '1+', 'match');
    fprintf(['AHI = ' num2str(length(M)/(length(x)/oafHz/60/60)) '\n']) ;



    % if there is a ~9Hz artifact, remove it
    Remove9HzART ;



    % if needed, examine CPC
    INSPECTCPC = 0 ;
    InspectCPC ;


    % save the original signal
    x1 = x ;
    ppgx1 = ppgx ;
    IHRx1 = IHRx ;


    %% start to run the decomposition

    %% Estimate apnea events (or use expert's labels if there is any)
    % 1=CSA 2=OSA 3=HYP (TODO -- HYP should be handled separately)
%     idx = ALx == 1 | ALx == 2 ;
%     [AM, Astart] = regexp(sprintf('%i', idx'), '1+', 'match') ;
%     AM = cellfun(@length, AM) ;





    xnoOC = x ;

    %% Step 1: reduce the impact of CO by SAMD

    for oo1 = 1: size(OCtime{Jidx}, 1)

        x = x1(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,2)*60*oafHz) ;
        IHRxE = IHRx1(OCtime{Jidx}(oo1,1)*60*IHRHz+1: OCtime{Jidx}(oo1,2)*60*IHRHz)/60 ;
        ppgx = ppgx1(OCtime{Jidx}(oo1,1)*60*PPGHz+1: OCtime{Jidx}(oo1,2)*60*PPGHz) ;

        [R1, Rs, Q, ~] = PPG_peakdetection2(ppgx, PPGHz) ;
        IHRx = interp1(Rs(2:end), PPGHz./diff(Rs), 1:length(ppgx), 'linear', 'extrap') ;
        IHRx = resample(IHRx, IHRHz, PPGHz) ;

        % truncate to simplify/speed up the SST algorithm (10m a segment)
        LEN = 600 ;
        BDRY = 10 ;

        NSEG = ceil(length(x) / (LEN*oafHz)) ;
        LEN = floor(length(x)/ oafHz / NSEG) ;
        x = x(1: LEN * NSEG * oafHz) ;

        [b, a] = butter(4, [0.6 4]/(oafHz/2)) ;
        BPFx = filtfilt(b, a, x) ;
        HRR = [quantile(IHRx, .1) quantile(IHRx, .99)] ;
        [COSAMD10, harm10, c10, tfrsq1, dstfrsq1, tfrsqtic] = ...
            SAMDforOC(BPFx, oafHz, LEN, BDRY, MULTI1{Jidx}, HRR, DIV1{Jidx}) ;

        
        COSAMD = resample(COSAMD10, oafHz, 10) ;
        xnoOC(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,1)*60*oafHz+length(COSAMD)) =...
            xnoOC(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,1)*60*oafHz+length(COSAMD)) - COSAMD' ;
        %harm1 = real(resample(harm10, oafHz, 10)) ;
        %harm1 = real(harm1(:)) ;


        % BPF
        [b, a] = butter(4, [quantile(IHRx, .01)-0.1 quantile(IHRx, .99)+0.1]/(oafHz/2)) ;
        CObpf100 = filtfilt(b, a, x) ;

        % SGF
        DDairflowsgf100 = sgolayfilt(x, 2, 2*oafHz+1) ;
        COsgf100 = filtfilt(b, a, x-DDairflowsgf100) ;


        % plot Step 1 result for observation

        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
        subplot(321) ; hold off
        imageSQ([1:10:length(BPFx)]/100/60, tfrsqtic*10, abs(tfrsq1), .99) ; colormap(1-gray)
        ylim([0.5 mean(IHRx)*5]) ; set(gca, 'fontsize', FONTSIZE)

        subplot(322) ; hold off
        imageSQ([1:10:length(BPFx)]/100/60, tfrsqtic*10, abs(tfrsq1), .99) ; colormap(1-gray)
        hold on ;
        plot([1:length(IHRx)]/IHRHz/60, smooth(IHRx, 60, 'loess'), 'b--','linewidth',2) ;
        plot([1:length(IHRx)]/IHRHz/60, 2*smooth(IHRx, 60, 'loess'), 'b--','linewidth',2) ;
        plot([1:length(c10)]/10/60, tfrsqtic(c10)*10, 'r','linewidth',2) ;
        ylim([0.5 mean(IHRx)*5]) ; set(gca, 'fontsize', FONTSIZE)

        ppgx2 = resample(ppgx, 100, PPGHz) ;
        [~, Rs, ~, ~] = PPG_peakdetection2(ppgx2, 100) ;
        Rs = Rs(diff(Rs) > 20) ;

        ax(3) = subplot(3,2,[3 4]) ; hold off
        MM = quantile(x, .99) * 1.4 ;
        plot([1:length(COSAMD)]/oafHz/60, x(:)-COSAMD(:), 'r', 'linewidth', 3) ; hold on ;
        plot([1:length(x)]/oafHz/60, x, 'color', [.7 .7 .7], 'linewidth', 2);
        legend('Cleaned oaf', 'raw oaf')
        axis([-inf inf -MM MM]) ; set(gca, 'fontsize', FONTSIZE)

        ax(4) = subplot(3,2,[5 6]) ; hold off
        MM = quantile(ppgx, .99) * 1.1 ;
        MMoc = quantile(COSAMD, .99) * 1.1 ;
        plot([1:length(COSAMD)]/oafHz/60, COSAMD, 'k', 'linewidth', 3); hold on ;
        plot([1:length(ppgx)]/PPGHz/60, MMoc*ppgx/MM-2*MMoc, 'b', 'linewidth', 3) ;
        plot(Rs/100/60, zeros(size(Rs)), 'rx', 'linewidth', 3) ;
        axis([-inf inf -3*MMoc MMoc]) ; set(gca, 'fontsize', FONTSIZE)
        xlabel('Time (m)') ; legend('oafSAMD', 'PPG')
        title(['STEP1: ' num2str(Jidx) '-' num2str(oo1)])
        linkaxes(ax, 'x') ;

    end % end of step 1 for each CO-segment





    %% Step 2: run OSADA (over the whole recording)


    % now, upsample to 400Hz to enhance alignment.
    oafHz400 = 400 ;
    x400 = resample(x1, oafHz400, oafHz) ;
    xnoOC400 = resample(xnoOC, oafHz400, oafHz) ;



    % get cycles
    if exist(['ManualAnnotations/RealAnnotations' num2str(Jidx) '.mat'], 'file')
        fprintf('\t*** existing manual annotations! Load it!\n')
        load(['ManualAnnotations/RealAnnotations' num2str(Jidx) '.mat'], 'annotations') ;
        bb = find(diff(annotations) < 0) ;
        if ~isempty(bb)
            bb = length(annotations) - bb(1) ;
        else
            bb = length(annotations) ;
        end
        fprintf(['\t ' num2str(bb) ' maually added cycles out of ' ...
            num2str(bb(1)-1) ' automatic detections\n']);
        seg.begEx = sort(annotations', 'ascend') ; clear annotations ;
        seg.begEx(seg.begEx > length(xnoOC)*4) = [] ;
    else
        fprintf('\t*** No manual annotations! Run automatic detection!\n')
        [seg] = getCycles(xnoOC, oafHz) ;

        % remove BROKEN periods, if any
        if ~isempty(BROKEN)
            for jj = size(BROKEN, 1): -1: 1
                tmp = find(seg.begEx >= BROKEN(jj, 1)*oafHz & seg.begEx <= BROKEN(jj, 2)*oafHz) ;
                seg.begEx(tmp) = [] ;
            end
        end

        % adjust the detected timing
        seg.begEx = (seg.begEx-1) * 4 + 1 ;
    end

    %     for jj = 1:length(seg.begEx)
    %         idx = max(1, round(seg.begEx(jj) - 0.2*oafHz400)): min(length(xnoOC400), round(seg.begEx(jj) + 0.2*oafHz400)) ;
    %         [~, b] = min(abs(xnoOC400(idx))) ;
    %         seg.begEx(jj) = max(1, round(seg.begEx(jj) - 0.2*oafHz400)) - 1 + b ;
    %     end

    [DDoafOSADA400, ~, ~, Y, YOCm, PERIODL] = DecomposeSig(xnoOC400, xnoOC400, oafHz400, seg.begEx, 1) ;
    DDoafOSADA400 = DDoafOSADA400(:) ;
    COOSADA400 = x400(:) - DDoafOSADA400 ;

    DDoafOSADA = DDoafOSADA400(1:4:end) ;
    COOSADA = COOSADA400(1:4:end) ;





    %% step 3: get the final CO by SAMD again

    COOSADASAMD = zeros(size(COOSADA)) ;

    % for each segment with OC
    for oo1 = 1: size(OCtime{Jidx}, 1)

        DDoafOSADAseg = DDoafOSADA(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,2)*60*oafHz) ;
        COOSADAseg = COOSADA(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,2)*60*oafHz) ;
        IHRxE = IHRx1(OCtime{Jidx}(oo1,1)*60*IHRHz+1: OCtime{Jidx}(oo1,2)*60*IHRHz)/60 ;
        ppgx = ppgx1(OCtime{Jidx}(oo1,1)*60*PPGHz+1: OCtime{Jidx}(oo1,2)*60*PPGHz) ;

        [R1, Rs, Q, ~] = PPG_peakdetection2(ppgx, PPGHz) ;
        IHRx = interp1(Rs(2:end), PPGHz./diff(Rs), 1:length(ppgx), 'linear', 'extrap') ;
        IHRx = resample(IHRx, IHRHz, PPGHz) ;

        LEN = 600 ;
        BDRY = 10 ;
        %NSEG = ceil(length(COOSADAseg) / (LEN*oafHz)) ;
        %LEN = floor(length(COOSADAseg)/ oafHz / NSEG) ;
        %COOSADAseg = COOSADAseg(1: LEN * NSEG * oafHz) ;

        HRR = [quantile(IHRx, .1) quantile(IHRx, .99)] ;
        % 3: use the 3rd harmonic, 1: divide 3rd harmonic by 1 as the base to run
        % SAMD
        [COOSADASAMD10, harm10, c10, tfrsq1, dstfrsq1, tfrsqtic] =...
            SAMDforOC(COOSADAseg, oafHz, LEN, BDRY, MULTI2{Jidx}, HRR, DIV2{Jidx}) ;

        COOSADASAMD(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,2)*60*oafHz)...
            = resample(COOSADASAMD10, oafHz, 10) ;






        %% generate TFR for visualization

        opt1.NoWindowsInConceFT = 2 ;
        opt1.NoConceFT = 30 ;
        opt1.WindowLength = oafHz*15+1 ;
        opt1.WindowBandwidth = 6 ;
        opt1.SamplingRate = oafHz ;
        opt1.HighFrequencyLimit = 0.5 ;
        opt1.LowFrequencyLimit = 0 ;
        opt1.FrequencyAxisResolution = 4e-4 ;
        opt1.HOP = 5 ;
        opt1.second = 1 ;
        opt1.smooth = 0 ;


        t1 = tic ;
        [~, ~, tfrsq2, ConceFT2, tfrsqtic, ~] = ...
            ConceFT_sqSTFT_C(COOSADAseg, opt1.LowFrequencyLimit, ...
            opt1.HighFrequencyLimit, opt1.FrequencyAxisResolution, opt1.HOP,...
            opt1.WindowLength, opt1.NoWindowsInConceFT, opt1.WindowBandwidth,...
            opt1.NoConceFT, 1, 0) ;
        toc(t1) ;
        time = [1:length(COOSADAseg)]/oafHz/60 ;

        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
        subplot_tight(5,1,[1 2],[0.025 0.062]) ;
        imageSQ(time(1:opt1.HOP:end), tfrsqtic*oafHz, abs(tfrsq2), .99) ; colormap(1-gray)
        set(gca, 'fontsize', FONTSIZE) ; ylabel('Frequency (Hz)') ;
        set(gca, 'xtick', []) ; ylim([0 8]) ; colorbar


        subplot_tight(5,1,[3 4],[0.025 0.062]) ; hold off
        imageSQ(time(1:opt1.HOP:end), tfrsqtic*oafHz, abs(tfrsq2), .99) ; colormap(1-gray)
        set(gca, 'fontsize', FONTSIZE) ; hold on ;
        plot([1:length(IHRx)]/IHRHz/60, smooth(IHRx, IHRHz*5, 'loess'), 'r', 'linewidth', 5)
        plot([1:length(IHRx)]/IHRHz/60, 2*smooth(IHRx, IHRHz*5, 'loess'), 'b', 'linewidth', 5)
        plot([1:length(IHRx)]/IHRHz/60, 3*smooth(IHRx, IHRHz*5, 'loess'), 'g', 'linewidth', 5)
        plot([1:length(IHRx)]/IHRHz/60, 4*smooth(IHRx, IHRHz*5, 'loess'), 'm', 'linewidth', 5)
        plot([1:length(IHRx)]/IHRHz/60, 5*smooth(IHRx, IHRHz*5, 'loess'), 'c', 'linewidth', 5)
        xlabel('Time (m)') ; ylabel('Frequency (Hz)') ; ylim([0 8]) ; colorbar


        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
        subplot_tight(5,1,[1 2],[0.025 0.062]) ;
        imageSQ(time(1:opt1.HOP:end), tfrsqtic*oafHz, abs(ConceFT2), .99) ; colormap(1-gray)
        set(gca, 'fontsize', FONTSIZE) ; ylabel('Frequency (Hz)') ;
        set(gca, 'xtick', []) ; ylim([0 8]) ; colorbar


        subplot_tight(5,1,[3 4],[0.025 0.062]) ; hold off
        imageSQ(time(1:opt1.HOP:end), tfrsqtic*oafHz, abs(ConceFT2), .99) ; colormap(1-gray)
        set(gca, 'fontsize', FONTSIZE) ; hold on ;
        plot([1:length(IHRx)]/IHRHz/60, smooth(IHRx, IHRHz*5, 'loess'), 'r', 'linewidth', 5)
        plot([1:length(IHRx)]/IHRHz/60, 2*smooth(IHRx, IHRHz*5, 'loess'), 'b', 'linewidth', 5)
        plot([1:length(IHRx)]/IHRHz/60, 3*smooth(IHRx, IHRHz*5, 'loess'), 'g', 'linewidth', 5)
        plot([1:length(IHRx)]/IHRHz/60, 4*smooth(IHRx, IHRHz*5, 'loess'), 'm', 'linewidth', 5)
        plot([1:length(IHRx)]/IHRHz/60, 5*smooth(IHRx, IHRHz*5, 'loess'), 'c', 'linewidth', 5)
        xlabel('Time (m)') ; ylabel('Frequency (Hz)') ; ylim([0 8]) ; colorbar


    end % end of the oo1 loop in step 3


    %% generate Figure 7 (OSA case)
%     if Jidx == 63
%         SP = OCtime{Jidx}(1) ; EP = OCtime{Jidx}(2) ;
%         rawsig = x0(SP*60*oafHz+1: EP*60*oafHz) ;
%         rawABD = ABD(SP*60*oafHz+1: EP*60*oafHz) ;
%         rawTHO = THO(SP*60*oafHz+1: EP*60*oafHz) ;
%         rawppg = ppgx1(SP*60*PPGHz+1: EP*60*PPGHz) ;
%         rawppg = rawppg - (smooth(medfilt1(rawppg, 100), 100, 'loess'))' ;
%         [R1, Rs, Q, ~] = PPG_peakdetection2(rawppg, PPGHz) ;
%         rawCO = COOSADA(SP*60*oafHz+1: EP*60*oafHz) ;
%         rawCOsamdU = COOSADASAMD(SP*60*oafHz+1: EP*60*oafHz) ;
%         sig = x0(SP*60*oafHz+1: EP*60*oafHz) ;
%         airflow = DDoafOSADA(SP*60*oafHz+1: EP*60*oafHz) ;
% 
% 
%         figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
%         plot([1:length(sig)]/100, sig, 'k', 'linewidth', 5);
%         hold on;
%         plot([1:length(sig)]/100, rawTHO*2+40, 'color', [.7 .7 .7], 'linewidth', 4);
%         plot([1:length(sig)]/100, -rawABD*2+65, 'color', [.7 .7 .7], 'linewidth', 4);
%         plot([1:length(sig)]/100, sig, 'k', 'linewidth', 4);
%         plot([1:length(sig)]/100, airflow-60, 'b', 'linewidth', 4);
% 
%         plot([1:length(sig)]/100, 3*real(rawCO)-105, 'r', 'linewidth', 4);
%         plot([1:length(sig)]/100, 3*real(rawCOsamdU)-125, 'm', 'linewidth', 4);
%         plot([1:length(rawppg)]/PPGHz, 3*rawppg/std(rawppg)-145, 'color',...
%             [.5 .5 .5], 'linewidth', 4);
%         axis tight
%         for jj = 1: length(Rs)
%             plot([Rs(jj) Rs(jj)]/PPGHz-120, [-145 -95], 'color', [.7 .7 .7], 'linewidth', 2) ;
%         end
% 
%         set(gca, 'fontsize', FONTSIZE) ; xlabel('Time (s)')
%         set(gca, 'ytick', [-50 -25 0 25 50]) ; xlim([0 60]) ; ylim([-155 80])
%         %export_fig(['Figure7'], '-transparent', '-pdf')
% 
%     end



    %% generate Figure 3 (this is normal)
    if (Jidx == 75 && (OCtime{Jidx}(1) == 29.8 || OCtime{Jidx}(1) == 12) ) ...
            || Jidx == 9 && OCtime{9}(1) == 13 ...
            || Jidx == 63
        SP = OCtime{Jidx}(1) ; EP = OCtime{Jidx}(2) ;
        rawsig = x0(SP*60*oafHz+1: EP*60*oafHz) ;
        rawABD = ABD(SP*60*oafHz+1: EP*60*oafHz) ;
        rawTHO = THO(SP*60*oafHz+1: EP*60*oafHz) ;
        rawppg = ppgx1(SP*60*PPGHz+1: EP*60*PPGHz) ;
        rawppg = rawppg - (smooth(medfilt1(rawppg, 100), 100, 'loess'))' ;
        [R1, Rs, Q, ~] = PPG_peakdetection2(rawppg, PPGHz) ;
        rawCO = COOSADA(SP*60*oafHz+1: EP*60*oafHz) ;
        rawCOsamdU = COOSADASAMD(SP*60*oafHz+1: EP*60*oafHz) ;
        sig = x0(SP*60*oafHz+1: EP*60*oafHz) ;
        airflow = DDoafOSADA(SP*60*oafHz+1: EP*60*oafHz) ;


        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
        plot([1:length(sig)]/oafHz, sig, 'k', 'linewidth', 5) ; hold on;
        plot([1:length(sig)]/oafHz, rawTHO*2+40, 'color', [.7 .7 .7], 'linewidth', 4);
        plot([1:length(sig)]/oafHz, -rawABD*2+65, 'color', [.7 .7 .7], 'linewidth', 4);
        plot([1:length(sig)]/oafHz, sig, 'k', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, airflow-60, 'b', 'linewidth', 4);

        plot([1:length(sig)]/oafHz, MMM{Jidx}*real(rawCO)-105, 'r', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, MMM{Jidx}*real(rawCOsamdU)-125, 'm', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, (MMM{Jidx}/3)*CObpf100-145, 'g', 'linewidth', 4) ;
        plot([1:length(sig)]/oafHz, (MMM{Jidx}/3)*COsgf100-165, 'c', 'linewidth', 4) ;
        plot([1:length(rawppg)]/PPGHz, 3*rawppg/std(rawppg)-185, 'color',...
            [.5 .5 .5], 'linewidth', 4);
        axis tight
        for jj = 1: length(Rs)
            plot([Rs(jj) Rs(jj)]/PPGHz, [-185 -95], 'color', [.7 .7 .7], 'linewidth', 2) ;
        end

        set(gca, 'fontsize', FONTSIZE) ; xlabel('Time (s)')
        set(gca, 'ytick', [-50 -25 0 25 50]) ; xlim([0 60]) ; ylim([-195 80])
        %export_fig(['Figure3'], '-transparent', '-pdf')

    end



    %% generate Figure 5 (this is CSA)
    if Jidx == 9 && OCtime{9}(1) == 13
        SP = 15 ; EP = 16 ;
        rawsig = x0(SP*60*oafHz+1: EP*60*oafHz) ;
        rawABD = ABD(SP*60*oafHz+1: EP*60*oafHz) ;
        rawTHO = THO(SP*60*oafHz+1: EP*60*oafHz) ;
        rawppg = ppgx1(SP*60*PPGHz+1: EP*60*PPGHz) ;
        rawppg = rawppg - (smooth(medfilt1(rawppg, 100), 100, 'loess'))' ;
        [R1, Rs, Q, ~] = PPG_peakdetection2(rawppg, PPGHz) ;
        rawCO = COOSADA(SP*60*oafHz+1: EP*60*oafHz) ;
        rawCOsamdU = COOSADASAMD(SP*60*oafHz+1: EP*60*oafHz) ;
        sig = x0(SP*60*oafHz+1: EP*60*oafHz) ;
        airflow = DDoafOSADA(SP*60*oafHz+1: EP*60*oafHz) ;


        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
        plot([1:length(sig)]/oafHz, sig, 'k', 'linewidth', 5); hold on;
        plot([1:length(sig)]/oafHz, rawTHO*2+40, 'color', [.7 .7 .7], 'linewidth', 4);
        plot([1:length(sig)]/oafHz, -rawABD*2+65, 'color', [.7 .7 .7], 'linewidth', 4);
        plot([1:length(sig)]/oafHz, sig, 'k', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, airflow-60, 'b', 'linewidth', 4);

        plot([1:length(sig)]/oafHz, 3*real(rawCO)-105, 'r', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, 3*real(rawCOsamdU)-125, 'm', 'linewidth', 4);
        plot([1:length(rawppg)]/PPGHz, 3*rawppg/std(rawppg)-145, 'color',...
            [.5 .5 .5], 'linewidth', 4);
        axis tight
        for jj = 1: length(Rs)
            plot([Rs(jj) Rs(jj)]/PPGHz, [-145 -95], 'color', [.7 .7 .7], 'linewidth', 2) ;
        end

        set(gca, 'fontsize', FONTSIZE) ; xlabel('Time (s)')
        set(gca, 'ytick', [-50 -25 0 25 50]) ; xlim([0 60]) ; ylim([-155 80])
        %export_fig(['Figure5'], '-transparent', '-pdf')
keyboard


        % generate the observation figure for slides.
        SP = 15.8 ; EP = 16.8 ; %SP = 13.4 ; EP = 14.4 ; %13-14 is for the challengin page
        rawsig = x0(SP*60*oafHz+1: EP*60*oafHz) ;
        rawABD = ABD(SP*60*oafHz+1: EP*60*oafHz) ;
        rawTHO = THO(SP*60*oafHz+1: EP*60*oafHz) ;
        rawppg = ppgx1(SP*60*PPGHz+1: EP*60*PPGHz) ;
        rawppg = rawppg - (smooth(medfilt1(rawppg, 100), 100, 'loess'))' ;
        [R1, Rs, Q, ~] = PPG_peakdetection2(rawppg, PPGHz) ;
        rawCO = COOSADA(SP*60*oafHz+1: EP*60*oafHz) ;
        rawCOsamdU = COOSADASAMD(SP*60*oafHz+1: EP*60*oafHz) ;
        sig = x0(SP*60*oafHz+1: EP*60*oafHz) ;
        airflow = DDoafOSADA(SP*60*oafHz+1: EP*60*oafHz) ;
        noise = sig' - airflow - rawCOsamdU ;
        Qidx = find(seg.begEx/4>SP*60*oafHz & seg.begEx/4<=EP*60*oafHz) ;
        begEx = round(seg.begEx(Qidx)/4) - SP*60*oafHz  ;

        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
        plot([1:length(sig)]/oafHz, sig, 'k', 'linewidth', 5); hold on;
        plot([1:length(sig)]/oafHz, airflow-60, 'b', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, real(rawCOsamdU)-90, 'm', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, real(noise)-100, 'r', 'linewidth', 4);
        plot([1:length(rawppg)]/PPGHz, 2*rawppg/std(rawppg)-110, 'color',...
            [.5 .5 .5], 'linewidth', 4);
        axis tight
        for jj = 1: length(Rs)
            plot([Rs(jj) Rs(jj)]/PPGHz, [-118 -85], 'color', [.7 .7 .7], 'linewidth', 2) ;
        end

        set(gca, 'fontsize', FONTSIZE) ; xlabel('Time (s)')
        set(gca, 'ytick', [-50 -25 0 25 50]) ; xlim([10 40]) ; ylim([-118 30])


    


        % generate the manifold model figure for slides.
        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/4]) ;
        plot([1:length(sig)]/oafHz, sig, 'k', 'linewidth', 5); hold on;
        %plot(begEx/oafHz, sig(begEx), 'ro', 'linewidth', 3, 'markersize', 20) ;
        set(gca, 'fontsize', FONTSIZE) ; xlabel('Time (s)') ; xlim([10 40]) ; ylim([-33 30])
        axis off

        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/4]) ;
        plot([1:length(sig)]/oafHz, airflow, 'b', 'linewidth', 4) ; hold on ;
        plot(begEx/oafHz, airflow(begEx), 'ro', 'linewidth', 3, 'markersize', 20) ;
        set(gca, 'fontsize', FONTSIZE) ; xlabel('Time (s)') ; xlim([10 40]) ; ylim([-33 30])
        axis off


        % plot PCA of all collected cycles
        idx = [] ; 
        for jj = 1: size(YOCm,2)
            ridx = max(1, jj-100): min(size(YOCm,2), jj+100) ;
            if abs(PERIODL(jj) - median(PERIODL(ridx))) > 3*mad(PERIODL(ridx)) ; idx = [idx jj] ; end
        end
        idx = setdiff(1: size(YOCm,2), idx) ;
        C = cov(YOCm(:, idx)') ;
        [u,l] = eig(C) ;
        YY = YOCm(:, idx) - repmat(mean(YOCm(:, idx),2), 1, length(idx)) ;
        PP = u(:, end-2:end)'*YY ;
        scatter3(PP(1,:), PP(2,:), PP(3,:), 30, PERIODL(idx)/400, 'filled')
        colorbar ; xlim([-800 800]) ; ylim([-800 800]) ; zlim([-800 800])
        set(gca, 'fontsize', 18) ;

        % plot example cycles
        plot([-1724:1724]/400, Y(:, Qidx+10), 'linewidth',3) ;
        axis tight ; axis off

        % plot data matrix
        imagesc([-1724:1724]/400, 1:size(Y,2), Y', [quantile(Y(:), .01) quantile(Y(:), 0.99)])
        xlabel('time (s)') ; ylabel('index');
        colorbar ; set(gca, 'fontsize', 18) ; axis xy


        % plot stitching result
        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/2]) ;
        plot([1:length(sig)]/oafHz, sig, 'k', 'linewidth', 5); hold on;
        plot([1:length(sig)]/oafHz, airflow-60, 'b', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, real(rawCO)-90, 'm', 'linewidth', 4);
        set(gca, 'fontsize', FONTSIZE) ; xlabel('Time (s)')
        set(gca, 'ytick', [-50 -25 0 25 50]) ; xlim([10 40]) ; ylim([-100 30])

        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*2/3]) ;
        plot([1:length(sig)]/oafHz, sig, 'k', 'linewidth', 5); hold on;
        plot([1:length(sig)]/oafHz, airflow-60, 'b', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, real(rawCO)-90, 'm', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, real(rawCOsamdU)-100, 'r', 'linewidth', 4);
        plot([1:length(rawppg)]/PPGHz, 2*rawppg/std(rawppg)-110, 'color',...
            [.5 .5 .5], 'linewidth', 4);
        axis tight
        for jj = 1: length(Rs)
            plot([Rs(jj) Rs(jj)]/PPGHz, [-118 -85], 'color', [.7 .7 .7], 'linewidth', 2) ;
        end

        set(gca, 'fontsize', FONTSIZE) ; xlabel('Time (s)')
        set(gca, 'ytick', [-50 -25 0 25 50]) ; xlim([10 40]) ; ylim([-118 30])
    end




    %% generate more Figure 7 (this is OSA)
    if Jidx == 53
        SP = 298.5 ; EP = 299.5 ;
        SP = 301 ; EP = 302 ;
        SP = 304 ; EP = 305 ;
        rawsig = x0(SP*60*oafHz+1: EP*60*oafHz) ;
        rawABD = ABD(SP*60*oafHz+1: EP*60*oafHz) ;
        rawTHO = THO(SP*60*oafHz+1: EP*60*oafHz) ;
        rawppg = ppgx1(SP*60*PPGHz+1: EP*60*PPGHz) ;
        rawppg = rawppg - (smooth(medfilt1(rawppg, 100), 100, 'loess'))' ;
        [R1, Rs, Q, ~] = PPG_peakdetection2(rawppg, PPGHz) ;
        rawCO = COOSADA(SP*60*oafHz+1: EP*60*oafHz) ;
        rawCOsamdU = COOSADASAMD(SP*60*oafHz+1: EP*60*oafHz) ;
        sig = x0(SP*60*oafHz+1: EP*60*oafHz) ;
        airflow = DDoafOSADA(SP*60*oafHz+1: EP*60*oafHz) ;


        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
        plot([1:length(sig)]/oafHz, sig, 'k', 'linewidth', 5); hold on;
        plot([1:length(sig)]/oafHz, rawTHO*2+40, 'color', [.7 .7 .7], 'linewidth', 4);
        plot([1:length(sig)]/oafHz, -rawABD*2+65, 'color', [.7 .7 .7], 'linewidth', 4);
        plot([1:length(sig)]/oafHz, sig, 'k', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, airflow-60, 'b', 'linewidth', 4);

        plot([1:length(sig)]/oafHz, 3*real(rawCO)-105, 'r', 'linewidth', 4);
        plot([1:length(sig)]/oafHz, 3*real(rawCOsamdU)-125, 'm', 'linewidth', 4);
        plot([1:length(rawppg)]/PPGHz, 3*rawppg/std(rawppg)-145, 'color',...
            [.5 .5 .5], 'linewidth', 4);
        axis tight
        for jj = 1: length(Rs)
            plot([Rs(jj) Rs(jj)]/PPGHz, [-145 -95], 'color', [.7 .7 .7], 'linewidth', 2) ;
        end
        set(gca, 'fontsize', FONTSIZE) ; xlabel('Time (s)')
        set(gca, 'ytick', [-50 -25 0 25 50]) ; xlim([0 60]) ; ylim([-155 80])
        %export_fig(['Figure7-extra'], '-transparent', '-pdf')

    end

end