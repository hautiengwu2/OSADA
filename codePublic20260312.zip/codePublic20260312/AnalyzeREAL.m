clear ; close all

addpath('./SST') ;
addpath('./SAMD') ;
addpath([PATH '/tool']) ;

% get tidal_breathing_segmentation-master online


DATABASE = 'Your Database' ;
N = 10 ; % number of recordings in your database

warningState = warning;  % Save current warning state
warning('off', 'all');   % Disable all warnings


FONTSIZE = 28 ;



AllDDaf_OSADA = {} ;
AllCO_OSADA = {} ;

omegaALL = [] ;
CUT = [] ;

%% run analysis for all subjects
for Jidx = 1: N

    fprintf(['\n\n**** ' num2str(Jidx) '\n'])
    loadData ;

    %% preprocess the signal
    % correct the gap. BROKEN is your manual label of broken segments
    if ~isempty(BROKEN)
        for kk= 1: size(BROKEN, 1)
            x(BROKEN(kk, 1)*oafHz+1: BROKEN(kk, 2)*oafHz) = 0 ;
        end
    end


    % POLAR_Change is your manual label if you need to change the polar
    % sign (of automatically detect it)
    if ismember(Jidx, POLAR_Change)
        x = -x ; oaf = -oaf ;
    end




    % correct OOR
    x0 = x ;
    idxbad = find(x == 100 | x == -100) ;
    idxgood = find(x < 100 & x > -100) ;
    x = interp1(idxgood, x(idxgood), [1:length(x)], 'spline', 'extrap') ;

    OORratio = round(10000 * length(idxbad) ./ length(x)) / 100 ;
    fprintf([num2str(Jidx) ': OOR ratio = ' num2str(OORratio) '%%\n']) ;


    AL = double(VGH.apnea_event.signal) ;
    t = AL > 0 ;
    [M, start] = regexp(sprintf('%i', [0 t]), '1+', 'match');
    fprintf(['AHI = ' num2str(length(M)/(length(x)/oafHz/60/60)) '\n']) ;



    % save the original signal
    x1 = x ;
    ppgx1 = ppgx ;
    IHRx1 = IHRx ;


    %% start to run the decomposition
    if ~exist(['DECOMP' num2str(Jidx) '.mat'], 'file')

        fprintf('No result exists -- decompse it!\n')


        %% Use expert's labels or estimate apnea/hypopnea events
        % 1=CSA 2=OSA 3=HYP 
        idx = ALx == 1 | ALx == 2 ;
        [AM, Astart] = regexp(sprintf('%i', idx'), '1+', 'match') ;
        AM = cellfun(@length, AM) ;

        xnoOC = x ;
        COSAMDall = {} ;
        xall = {} ;

        %% Step 1: reduce the impact of CO by SAMD
        % for each segment with OC using experts' label (or estimate it)
        for oo1 = 1: size(OCtime{Jidx}, 1)

            x = x1(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,2)*60*oafHz) ;
            IHRx = IHRx1(OCtime{Jidx}(oo1,1)*60*IHRHz+1: OCtime{Jidx}(oo1,2)*60*IHRHz) ;
            ppgx = ppgx1(OCtime{Jidx}(oo1,1)*60*PPGHz+1: OCtime{Jidx}(oo1,2)*60*PPGHz) ;

            % truncate to simplify/speed up the SST algorithm (10m a segment)
            LEN = 600 ;
            BDRY = 10 ;

            NSEG = ceil(length(x) / (LEN*oafHz)) ;
            LEN = floor(length(x)/ oafHz / NSEG) ;
            x = x(1: LEN * NSEG * oafHz) ;
            % test up to here


            [b, a] = butter(4, [0.6 4]/(oafHz/2)) ;
            BPFx = filtfilt(b, a, x) ;
            HRR = [quantile(IHRx, .1) quantile(IHRx, .99)]/60 ;
            [COSAMD10, harm10, c10, tfrsq1, dstfrsq1, tfrsqtic] = SAMDforOC(BPFx, oafHz, LEN, BDRY, 1, HRR) ;


            COSAMD = resample(COSAMD10, oafHz, 10) ;
            COSAMDall{oo1} = COSAMD(:) ;
            xall{oo1} = xall ;
            %xnoOC = x(:) - COSAMD ;
            harm1 = real(resample(harm10, oafHz, 10)) ;
            harm1 = real(harm1(:)) ;

            % remove the 2nd harmonic! (before removed SAMD)
            xnoOC(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,1)*60*oafHz+length(COSAMD)) =...
                xnoOC(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,1)*60*oafHz+length(COSAMD)) - COSAMD' ;


            % plot Step 1 result for observation
            if 0

                %ax(1) =
                subplot(321) ; hold off
                imageSQ([1:10:length(BPFx)]/100/60, tfrsqtic*10, abs(tfrsq1), .99) ; colormap(1-gray)
                ylim([0.5 mean(IHRx/60)*3]) ; set(gca, 'fontsize', FONTSIZE)

                %ax(2) =
                subplot(322) ; hold off
                imageSQ([1:10:length(BPFx)]/100/60, tfrsqtic*10, abs(tfrsq1), .99) ; colormap(1-gray)
                hold on ;
                plot([1:length(IHRx)]/IHRHz/60, smooth(IHRx, 60, 'loess')/60, 'b--','linewidth',2) ;
                plot([1:length(IHRx)]/IHRHz/60, 2*smooth(IHRx, 60, 'loess')/60, 'b--','linewidth',2) ;
                plot([1:length(c10)]/10/60, tfrsqtic(c10)*10, 'r','linewidth',2) ;
                ylim([0.5 mean(IHRx/60)*3]) ; set(gca, 'fontsize', FONTSIZE)

                ppgx2 = resample(ppgx, 100, PPGHz) ;
                [~, Rs, ~, ~] = PPG_peakdetection2(ppgx2, 100) ;
                Rs = Rs(diff(Rs) > 20) ;

                ax(3) = subplot(3,2,[3 4]) ; hold off
                MM = quantile(x, .99) * 1.4 ;
                plot([1:length(COSAMD)]/oafHz/60, x(:)-COSAMD(:), 'r', 'linewidth', 3) ; hold on ;
                plot([1:length(x)]/oafHz/60, x, 'color', [.7 .7 .7], 'linewidth', 2);
                legend('Cleaned oaf', 'raw oaf')
                axis([-inf inf -MM MM]) ; set(gca, 'fontsize', FONTSIZE)

                ax(4) = subplot(3,2,[5 6]) ; hold off
                MM = quantile(ppgx, .99) * 1.1 ;
                MMoc = quantile(COSAMD, .99) * 1.1 ;
                plot([1:length(COSAMD)]/oafHz/60, COSAMD, 'k', 'linewidth', 3); hold on ;
                plot([1:length(ppgx)]/PPGHz/60, MMoc*ppgx/MM-2*MMoc, 'b', 'linewidth', 3) ;
                plot(Rs/100/60, zeros(size(Rs)), 'rx', 'linewidth', 3) ;
                %plot(Rs/100/60, COSAMD(Rs), 'rx', 'linewidth', 3) ;
                axis([-inf inf -3*MMoc MMoc]) ; set(gca, 'fontsize', FONTSIZE)
                xlabel('Time (m)') ; legend('oafSAMD', 'PPG')
                title(['STEP1: ' num2str(Jidx) '-' num2str(oo1)])

                linkaxes(ax, 'x') ;


                % plot 1.5 mins per figure
                ooN = ceil((OCtime{Jidx}(oo1, 2) - OCtime{Jidx}(oo1, 1))/1.5) ;
                ooL = (OCtime{Jidx}(oo1, 2) - OCtime{Jidx}(oo1, 1)) / ooN ;
                for oo2 = 1 %: ooN
                    xlim([(oo2-1)*ooL oo2*ooL]) ;
                    %export_fig([num2str(Jidx) '-' num2str(oo1) '-' num2str(oo2) '-Step1'], '-transparent', '-m2')
                end

            end

        end % end of step 1 for each CO-segment





        %% Step 2: run OSADA (over the whole recording)


        % now, upsample to 400Hz to enhance alignment.
        oafHz400 = 400 ;
        x400 = resample(x1, oafHz400, oafHz) ;
        xnoOC400 = resample(xnoOC, oafHz400, oafHz) ;



        % get cycles
        if exist(['ManualAnnotations/RealAnnotations' num2str(Jidx) '.mat'], 'file')
            fprintf('\t*** existing manual annotations! Load it!\n')
            load(['ManualAnnotations/RealAnnotations' num2str(Jidx) '.mat'], 'annotations') ;
            bb = find(diff(annotations) < 0) ;
            if ~isempty(bb)
                bb = length(annotations) - bb(1) ;
            else
                bb = length(annotations) ;
            end
            fprintf(['\t ' num2str(bb) ' maually added cycles out of ' ...
                num2str(bb(1)-1) ' automatic detections\n']);
            seg.begEx = sort(annotations', 'ascend') ; clear annotations ;
            seg.begEx(seg.begEx > length(xnoOC)*4) = [] ;
        else
            fprintf('\t*** No manual annotations! Run automatic detection!\n')
            [seg] = getCycles(xnoOC, oafHz) ;

            % remove BROKEN periods, if any
            if ~isempty(BROKEN)
                for jj = size(BROKEN, 1): -1: 1
                    tmp = find(seg.begEx >= BROKEN(jj, 1)*oafHz & seg.begEx <= BROKEN(jj, 2)*oafHz) ;
                    seg.begEx(tmp) = [] ;
                end
            end

            % adjust the detected timing
            seg.begEx = (seg.begEx-1) * 4 + 1 ;
        end

        for jj = 1:length(seg.begEx)
            idx = max(1, round(seg.begEx(jj) - 0.2*oafHz400)): min(length(xnoOC400), round(seg.begEx(jj) + 0.2*oafHz400)) ;
            [~, b] = min(abs(xnoOC400(idx))) ;
            seg.begEx(jj) = max(1, round(seg.begEx(jj) - 0.2*oafHz400)) - 1 + b ;
        end



        % for the detected apnea events, remove the detected breathing cycles
        if 0
            for jj = length(Astart)-1: -1: 1
                tmp = seg.begEx >= Astart(jj)*oafHz/ALHz ...
                    & seg.begEx <= (Astart(jj)+AM(jj))*oafHz/ALHz-1 ;
                seg.begEx(tmp) = [] ;
            end
        end




        [DDoafOSADA400, ~] = DecomposeSig(xnoOC400, xnoOC400, oafHz400, seg.begEx, 3) ;
        DDoafOSADA400 = DDoafOSADA400(:) ;
        COOSADA400 = x400(:) - DDoafOSADA400 ;

        DDoafOSADA = DDoafOSADA400(1:4:end) ;
        COOSADA = COOSADA400(1:4:end) ;

        

        %% step 3: get the final cleaned CO by SAMD again

        COOSADASAMDall = {} ;
        DDoafOSADAall = {} ;

        % for each segment with OC
        for oo1 = 1: size(OCtime{Jidx}, 1)

            DDoafOSADAseg = DDoafOSADA(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,2)*60*oafHz) ;
            COOSADAseg = COOSADA(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,2)*60*oafHz) ;
            IHRx = IHRx1(OCtime{Jidx}(oo1,1)*60*IHRHz+1: OCtime{Jidx}(oo1,2)*60*IHRHz) ;
            ppgx = ppgx1(OCtime{Jidx}(oo1,1)*60*PPGHz+1: OCtime{Jidx}(oo1,2)*60*PPGHz) ;

            LEN = 600 ;
            BDRY = 10 ;
            NSEG = ceil(length(COOSADAseg) / (LEN*oafHz)) ;
            LEN = floor(length(COOSADAseg)/ oafHz / NSEG) ;
            COOSADAseg = COOSADAseg(1: LEN * NSEG * oafHz) ;

            HRR = [quantile(IHRx, .1) quantile(IHRx, .99)]/60 ;
            [COOSADASAMD10, harm10, c10, tfrsq2, ~, tfrsqtic] = SAMDforOC(COOSADAseg, oafHz, LEN, BDRY, 1, HRR) ;
            COOSADASAMD = resample(COOSADASAMD10, oafHz, 10) ;
            COOSADAall{oo1} = COOSADAseg(:) ;
            COOSADASAMDall{oo1} = COOSADASAMD(:) ;
            DDoafOSADAall{oo1} = DDoafOSADAseg(:) ;

             

            % plot Step 3 result for observation
            if 1
                QQQx = x1(OCtime{Jidx}(oo1,1)*60*oafHz+1: 10: OCtime{Jidx}(oo1,2)*60*oafHz) ;

                subplot(321) ; hold off
                imageSQ([1:length(QQQx)]/10/60, tfrsqtic*10, abs(tfrsq2), .99) ; colormap(1-gray)
                ylim([0.5 3*mean(IHRx/60)]) ; set(gca, 'fontsize', FONTSIZE)

                subplot(322) ; hold off
                imageSQ([1:length(QQQx)]/10/60, tfrsqtic*10, abs(tfrsq2), .99) ; colormap(1-gray)
                hold on ;
                plot([1:length(IHRx)]/IHRHz/60, smooth(IHRx, 60, 'loess')/60, 'b--','linewidth',2) ;
                plot([1:length(IHRx)]/IHRHz/60, 2*smooth(IHRx, 60, 'loess')/60, 'b--','linewidth',2) ;
                plot([1:length(c10)]/10/60, tfrsqtic(c10)*10, 'r','linewidth', 3) ;
                ylim([0.5 3*mean(IHRx/60)]) ; set(gca, 'fontsize', FONTSIZE)

                ppgx2 = resample(ppgx, 100, PPGHz) ;
                [~, Rs, ~, ~] = PPG_peakdetection2(ppgx2, 100) ;
                Rs = Rs(diff(Rs) > 20) ;
                rri = seg.begEx(find(seg.begEx < OCtime{Jidx}(oo1,2)*60*oafHz & seg.begEx > OCtime{Jidx}(oo1,1)*60*oafHz)) ;
                RR = 1./median(diff(rri)/oafHz) ;
                HR = 1./median(diff(Rs)/100) ;

                ax(3) = subplot(3,2,[3 4]) ; hold off
                MM = quantile(abs(QQQx), .99) * 1.1 ;
                plot([1:length(QQQx)]/10/60, QQQx, 'color', [.7 .7 .7], 'linewidth', 2); hold on ;
                plot([1:length(DDoafOSADAall{oo1})]/oafHz/60, DDoafOSADAall{oo1}, 'k', 'linewidth', 2);
                legend('oaf', 'OSADAoaf')
                axis([-inf inf -MM MM]) ; set(gca, 'fontsize', FONTSIZE)

                ax(4) = subplot(3,2,[5 6]) ; hold off
                MM = quantile(ppgx, .99) * 1.1 ;
                MMoc = quantile(COOSADASAMD, .99) * 1.1 ;
                MMosada = quantile(COOSADAall{oo1}, .99) * 1.1 ;
                plot([1:length(COOSADASAMD)]/oafHz/60, COOSADAall{oo1}, 'b', 'linewidth', 3); hold on ;
                plot([1:length(COOSADASAMD)]/oafHz/60, COOSADASAMDall{oo1}-MMoc-MMosada, 'k', 'linewidth', 3); hold on ;
                plot([1:length(ppgx)]/PPGHz/60, MMoc*ppgx/MM-MMosada-3*MMoc, 'color', [.7 .7 .7], 'linewidth', 2) ;
                plot(Rs/100/60, zeros(size(Rs)), 'rx', 'linewidth', 3) ;
                axis([-inf inf -4*MMoc-MMosada MMosada]) ; set(gca, 'fontsize', FONTSIZE)
                xlabel('Time (m)') ; legend('osada', 'osada+SAMD', 'PPG')
                title(['STEP3: ' num2str(Jidx) '-' num2str(oo1) ': HR/RR = ' num2str(HR/RR)])

                linkaxes(ax, 'x') ;


                % plot 1.5 mins per figure
                ooN = ceil((OCtime{Jidx}(oo1, 2) - OCtime{Jidx}(oo1, 1))/1.5) ;
                ooL = (OCtime{Jidx}(oo1, 2) - OCtime{Jidx}(oo1, 1)) / ooN ;
                for oo2 = 1 %: ooN
                    xlim([(oo2-1)*ooL oo2*ooL]) ;
                    export_fig([num2str(Jidx) '-' num2str(oo1) '-' num2str(oo2) '-Step3'], '-transparent', '-m2')
                end

            end






            if 0
                % plot OSADA result for observation
                %figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
                ax(1) = subplot(211) ; hold off
                MMoaf = quantile(abs(x), .99) * 1.2 ;
                plot([1:length(x)]/oafHz/60, x, 'color', [.7 .7 .7], 'linewidth', 3);
                hold on;
                plot([1:length(DDoafOSADA)]/oafHz/60, DDoafOSADA, 'b', 'linewidth', 3);
                plot(seg.begEx/oafHz400/60, x400(seg.begEx), 'rx', 'linewidth', 3, 'markersize', 12)
                ALy = ALx ; ALy(ALx==0) = nan ; ALy(ALx==3) = nan ;
                plot([1:length(ALy)]/ALHz/60, ALy*5, 'k', 'linewidth', 3) ;
                set(gca, 'fontsize', FONTSIZE) ; xlabel('Time (m)') ; ylim([-MMoaf MMoaf]) ;

                ppgx2 = resample(ppgx, 100, PPGHz) ;
                [~, Rs, ~, ~] = PPG_peakdetection2(ppgx2, 100) ;
                Rs = Rs(diff(Rs) > 20) ;

                MM = quantile(ppgx, .99) * 1.4 ;
                MMoc = quantile(COOSADA, .99) * 1.2 ;
                ax(2) = subplot(212) ; hold off
                plot([1:length(COOSADA)]/oafHz/60, COOSADA, 'k', 'linewidth', 3); hold on ;
                plot([1:length(ppgx)]/PPGHz/60, MMoc*ppgx/MM-2*MMoc, 'b', 'linewidth', 3) ;
                plot(Rs/100/60, zeros(size(Rs)), 'rx', 'linewidth', 3) ;
                axis([-inf inf -3*MMoc MMoc])
                set(gca, 'fontsize', FONTSIZE)
                xlabel('Time (m)')

                linkaxes(ax, 'x') ;


                % plot 2 mins per figure
                ooN = ceil((OCtime{Jidx}(oo1, 2) - OCtime{Jidx}(oo1, 1))/2) ;
                ooL = (OCtime{Jidx}(oo1, 2) - OCtime{Jidx}(oo1, 1)) / ooN ;
                for oo2 = 1: ooN
                    xlim(OCtime{Jidx}(oo1,1) + [(oo2-1)*ooL oo2*ooL]) ;
                    export_fig([num2str(Jidx) '-' num2str(oo1) '-' num2str(oo2)], '-transparent', '-m2')
                end

            end



            % plot TFR for visualization
            if 0
                time = [1:10:length(COOSADA)]/100/60 ;
                subplot(211)
                imageSQ(time(1:2:end), tfrsqtic*10, abs(tfrsq2(:, 1:2:end)), .99) ; colormap(1-gray)
                set(gca, 'fontsize', 24) ; ylabel('Freq (Hz)') ;
                title(['Jidx =' num2str(Jidx) '; OOR = ' num2str(OORratio) '%; AHI = '...
                    num2str(length(M)/(length(x)/oafHz/60/60))]) ;

                subplot(212) ; hold off
                imageSQ(time(1:2:end), tfrsqtic*10, abs(tfrsq2(:, 1:2:end)), .95) ; colormap(1-gray)
                set(gca, 'fontsize', 24) ; hold on ;
                plot([1:length(IHRP)]/IHRHz/60, smooth(IHRP/60, IHRHz*30, 'loess'), 'r--', 'linewidth', 3)
                plot([1:length(IHRP)]/IHRHz/60, 2*smooth(IHRP/60, IHRHz*30, 'loess'), 'm--', 'linewidth', 3)
                xlabel('Time (m)') ; ylabel('Freq (Hz)')

                ceil(time(end)/60)

                for Ljj = 1: ceil(time(end)/60)
                    subplot(211) ; axis([(Ljj-1)*60 Ljj*60 0 3])
                    subplot(212) ; axis([(Ljj-1)*60 Ljj*60 0 3])
                    export_fig(['IMG-' num2str(Jidx) '-' num2str(Ljj)], '-transparent', '-m2')
                end
            end

        end % end of the oo1 loop in step 3

        save(['DECOMP' num2str(Jidx)], 'xall', 'COSAMDall', 'COOSADAall', 'COOSADASAMDall', 'DDoafOSADAall') ;


    else

        fprintf('Found result! Load it & continue \n')
        load(['DECOMP' num2str(Jidx) '.mat'])

    end


    %% Get other algorithms' result for comparison

    [CObpf, DDairflowbpf, COsgf, DDairflowsgf] = OtherAlgorithm(x1,...
        TipTraQ.green.ihr.signal, oafHz) ;

    CObpfall = {} ;
    COsgfall = {} ;
    DDairflowbpfall = {} ;
    DDairflowsgfall = {} ;

    for oo1 = 1: size(OCtime{Jidx}, 1)
        CObpfseg = CObpf(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,2)*60*oafHz) ;
        CObpfall{oo1} = CObpfseg(:) ;

        COsgfseg = COsgf(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,2)*60*oafHz) ;
        COsgfall{oo1} = COsgfseg(:) ;

        DDairflowbpfseg = DDairflowbpf(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,2)*60*oafHz) ;
        DDairflowbpfall{oo1} = DDairflowbpfseg(:) ;

        DDairflowsgfseg = DDairflowsgf(OCtime{Jidx}(oo1,1)*60*oafHz+1: OCtime{Jidx}(oo1,2)*60*oafHz) ;
        DDairflowsgfall{oo1} = DDairflowsgfseg(:) ;

        if length(DDairflowsgfall{oo1}) < length(COSAMDall{oo1})
            keyboard
        elseif length(DDairflowsgfall{oo1}) > length(COSAMDall{oo1})
            CObpfall{oo1} = CObpfall{oo1}(1: length(COSAMDall{oo1})) ;
            COsgfall{oo1} = COsgfall{oo1}(1: length(COSAMDall{oo1})) ;
            DDairflowbpfall{oo1} = DDairflowbpfall{oo1}(1: length(COSAMDall{oo1})) ;
            DDairflowsgfall{oo1} = DDairflowsgfall{oo1}(1: length(COSAMDall{oo1})) ;
        end
    end


    



    %% evaluate the performance
    % this is the ONLY index for real data
    % evaluate CO recovery every 2 minutes

    [PHI, time] = generatePhase(ppgx1, PPGHz) ;
    EVALlen = 2 ;

    for oo1 = 1: size(OCtime{Jidx}, 1)

        COOSADAall{oo1} = COOSADASAMDall{oo1} ; %!!!!!!!!!

        idx = OCtime{Jidx}(oo1, 1)*60*oafHz+1: OCtime{Jidx}(oo1, 1)*60*oafHz + length(CObpfall{oo1}) ;
        [omega0] = genREALindex(CObpfall{oo1}, COsgfall{oo1}, COSAMDall{oo1}, COOSADAall{oo1},...
            COOSADASAMDall{oo1}, PHI(idx)'-PHI(idx(1)-1), EVALlen) ;
        % Left to right: osadaSAMD, bpf, sgf, oafSAMD
        omega_bpf0 = omega0(:, 2) ;
        omega_sgf0 = omega0(:, 3) ;
        omega_oafSAMD0 = omega0(:, 4) ;
        omega_osadaSAMD0 = omega0(:, 1) ;
        omega_osada0 = omega0(:, 5) ;

        disp([mean(omega_bpf0) mean(omega_sgf0) mean(omega_oafSAMD0) mean(omega_osadaSAMD0) mean(omega_osada0)]) ;
        % collect all indices for all subjects
        omegaALL = [omegaALL; omega0] ;
    end

    CUT = [CUT size(omegaALL, 1)] ;

end













%% report all results
errall = [omegaALL(:, 2) omegaALL(:, 3) omegaALL(:, 4) omegaALL(:, 1)] ;
LABEL = {'BPF', 'SGF', 'oafSAMD', 'osadaSAMD'} ;


errall = [omegaALL(:, 2) omegaALL(:, 3) omegaALL(:, 1)] ;
LABEL = {'BPF', 'SGF', 'OSADA'} ;

figure ;
[h,L,MX,MED] = violin(errall) ;
set(gca,'TickLabelInterpreter', 'latex');
set(gca,'xtick',1:length(LABEL))
set(gca,'xticklabel', LABEL) ;
%18 in mac, 22 in big monitor
xtickangle(25) ; set(gca,'fontsize', 18) ; legend off
ylabel('$\omega_c$ (n.u.)', 'interpreter','latex')

fprintf('\n\n\n')
disp([mean(omegaALL(:, 2)) mean(omegaALL(:, 3)) mean(omegaALL(:, 4)) mean(omegaALL(:, 1))]) ;
disp([std(omegaALL(:, 2)) std(omegaALL(:, 3)) std(omegaALL(:, 4)) std(omegaALL(:, 1))]) ;

disp([median(omegaALL(:, 2)) median(omegaALL(:, 3)) median(omegaALL(:, 4)) median(omegaALL(:, 1))]) ;
disp([mad(omegaALL(:, 2)) mad(omegaALL(:, 3)) mad(omegaALL(:, 4)) mad(omegaALL(:, 1))]) ;

save REALomegaALL omegaALL

 


SummarizeOCstrength ;


 