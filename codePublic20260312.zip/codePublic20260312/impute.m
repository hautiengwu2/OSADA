function [Imp] = impute(sig, fs, LIB, LIBmean)

% time unit in hour to simplify the discussion.
% Set the boundary intervals to be 1 hour.

% find the calibration segments (assume knowledge 0)
idx1 = find(~isnan(sig)) ;
sigMEAN = mean(sig(idx1)) ;
idx2 = isnan(sig) ;
[M, start] = regexp(sprintf('%i', [idx2']), '1+', 'match');
M = cellfun(@length, M);


% find sufficiently long missing segments
% and run Taken's embedding
FLen = round(fs*0.1) ;
Imp = sig ;

if ~isempty(M)
    fprintf(['\t*** Handle ' num2str(length(M)) ' missing periods\n']) ;

    for qi = 1: length(M)
        fprintf(['\t\t ' num2str(qi) '-th missing period\n']) ;
        % correct those zeros in the recording

        cal = start(qi): start(qi)+M(qi)-1 ;
        if start(qi)-FLen < 1
            llen = start(qi)-1 ;
        else
            llen = FLen ;
        end

        if start(qi) + M(qi) + FLen > length(sig)
            rlen = length(sig) - (start(qi)+M(qi)) ;
        else
            rlen = FLen ;
        end

        % determine the pattern to fit
        patternL = [start(qi)-llen: start(qi)-1] ;
        patternR = [start(qi) + M(qi) + 1: start(qi) + M(qi) + rlen] ;

        X = sig([patternL patternR]) - sigMEAN ;

        Dist = inf ;

        FIT = zeros(length(cal), 1) ;
        for lll = 1: length(LIB)
            if length(LIB{lll}) > M(qi) + llen + rlen + 1
                % jump every one min.
                for ppp = 1: 60: length(LIB{lll}) - M(qi) - rlen - llen - 1
                    patternLf = ppp: ppp+llen-1 ;
                    patternRf = ppp+llen + M(qi) + 1: ppp+llen + M(qi) + rlen ;
                    X0 = LIB{lll}([patternLf patternRf]) ;

                    % find the most similar pattern from the remainig signal for
                    % imputation. Also minimize the jump

                    Q = [sig(patternL(max(1,end-10):end)) ...
                        LIB{lll}(ppp+llen: ppp+llen+M(qi)-1) + LIBmean(lll) ...
                        sig(patternR(1:min(10, length(patternR))))] ;
                    Q = diff(Q) ;
                    tmp0 = ~isnan(Q) ;

                    ERR = X0 - X ;
                    tmp = ~isnan(ERR) ;
                    dd = std(ERR(tmp)) * std(Q(tmp0)) ;
                    if dd < Dist
                        Dist = dd ;
                        FIT = LIB{lll}(ppp+llen: ppp+llen+M(qi)-1) + LIBmean(lll) ;
                    end
                end
            end
        end

        Imp(cal) = FIT ;

    end
end


