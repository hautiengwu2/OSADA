function [OUTPUT] = unwarpsignalv2(INPUT, time, PHI0)

% INPUT: f(t), which is g(\phi(t))
% time: original time of f(t), PHI0: estimated \phi(t)
% OUTPUT: g(t)


% the initial value \phi(0) should be shifted to 0 to calculate 
% the dilation factor Qf
Qf = (time(end)-time(1)) / (PHI0(end)-PHI0(1)) ;

% this is the inverse-phase for warpping (pchip before)
PHIinv = interp1(PHI0, time, linspace(PHI0(1), PHI0(end), ceil(length(time)/Qf)), 'linear', 'extrap') ;

% unwarp OC using PHI 
OUTPUT = interp1(PHIinv, INPUT, time, 'pchip', 'extrap') ;
